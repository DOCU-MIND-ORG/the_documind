package com.accenture.intern.docmind;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocMindApplicationTests {

    @Test
    void contextLoads() {
    }

}
